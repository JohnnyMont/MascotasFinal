package Visual;
import Visual.Servico.AlterServico;
import Visual.Servico.CadastrarServicos;
import Visual.Servico.ConsulServico;
import Visual.Servico.ExcluirServico;
import Visual.Servico.PromoServico;
public class PrincipalAdm extends javax.swing.JFrame {
    public PrincipalAdm() {
        setUndecorated(true);
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuItem7 = new javax.swing.JMenuItem();
        jMenuItem9 = new javax.swing.JMenuItem();
        jLabel1 = new javax.swing.JLabel();
        jToggleButton1 = new javax.swing.JToggleButton();
        jLabel9 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu2 = new javax.swing.JMenu();
        cadservico = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        ConsultarServico = new javax.swing.JMenuItem();
        ExcluirServico = new javax.swing.JMenuItem();
        PromoServico = new javax.swing.JMenuItem();
        relatorio = new javax.swing.JMenu();
        jMenuItem5 = new javax.swing.JMenuItem();

        jMenuItem7.setText("jMenuItem7");

        jMenuItem9.setText("jMenuItem9");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Montserrat Alternates", 3, 48)); // NOI18N
        jLabel1.setText("Bem-Vindo Administrador!");

        jToggleButton1.setBackground(java.awt.Color.blue);
        jToggleButton1.setFont(new java.awt.Font("Serif", 1, 48)); // NOI18N
        jToggleButton1.setForeground(java.awt.Color.white);
        jToggleButton1.setText("Sair");
        jToggleButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton1ActionPerformed(evt);
            }
        });

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cats2.png"))); // NOI18N

        jButton2.setBackground(java.awt.Color.blue);
        jButton2.setFont(new java.awt.Font("Noto Sans", 0, 48)); // NOI18N
        jButton2.setForeground(java.awt.Color.white);
        jButton2.setText("X");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jMenuBar1.setBackground(new java.awt.Color(0, 0, 240));
        jMenuBar1.setForeground(new java.awt.Color(255, 255, 255));

        jMenu2.setForeground(new java.awt.Color(255, 255, 255));
        jMenu2.setText("Serviço");

        cadservico.setBackground(new java.awt.Color(0, 0, 240));
        cadservico.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        cadservico.setForeground(new java.awt.Color(255, 255, 255));
        cadservico.setText("Cadastrar");
        cadservico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cadservicoActionPerformed(evt);
            }
        });
        jMenu2.add(cadservico);

        jMenuItem2.setBackground(new java.awt.Color(0, 0, 240));
        jMenuItem2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jMenuItem2.setForeground(new java.awt.Color(255, 255, 255));
        jMenuItem2.setText("Alterar Dados");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem2);

        ConsultarServico.setBackground(new java.awt.Color(0, 0, 240));
        ConsultarServico.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        ConsultarServico.setForeground(new java.awt.Color(255, 255, 255));
        ConsultarServico.setText("Consultar");
        ConsultarServico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConsultarServicoActionPerformed(evt);
            }
        });
        jMenu2.add(ConsultarServico);

        ExcluirServico.setBackground(new java.awt.Color(0, 0, 240));
        ExcluirServico.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        ExcluirServico.setForeground(new java.awt.Color(255, 255, 255));
        ExcluirServico.setText("Excluir");
        ExcluirServico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExcluirServicoActionPerformed(evt);
            }
        });
        jMenu2.add(ExcluirServico);

        PromoServico.setBackground(new java.awt.Color(0, 0, 204));
        PromoServico.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        PromoServico.setForeground(new java.awt.Color(255, 255, 255));
        PromoServico.setText("Colocar serviço em promoção");
        PromoServico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PromoServicoActionPerformed(evt);
            }
        });
        jMenu2.add(PromoServico);

        jMenuBar1.add(jMenu2);

        relatorio.setForeground(new java.awt.Color(255, 255, 255));
        relatorio.setText("Relatórios");

        jMenuItem5.setBackground(new java.awt.Color(0, 0, 240));
        jMenuItem5.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jMenuItem5.setForeground(new java.awt.Color(255, 255, 255));
        jMenuItem5.setText("Gerar");
        jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem5ActionPerformed(evt);
            }
        });
        relatorio.add(jMenuItem5);

        jMenuBar1.add(relatorio);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jToggleButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                        .addComponent(jButton2)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 351, Short.MAX_VALUE)
                .addComponent(jToggleButton1)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    private void PromoServicoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PromoServicoActionPerformed
        PromoServico promocao = new PromoServico();
        promocao.setVisible(true);
    }//GEN-LAST:event_PromoServicoActionPerformed
    private void cadservicoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cadservicoActionPerformed
        CadastrarServicos cadservico = new CadastrarServicos();
        cadservico.setVisible(true);
    }//GEN-LAST:event_cadservicoActionPerformed
    private void ConsultarServicoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConsultarServicoActionPerformed
        ConsulServico consulServico = new ConsulServico();
        consulServico.setVisible(true);
    }//GEN-LAST:event_ConsultarServicoActionPerformed
    private void ExcluirServicoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExcluirServicoActionPerformed
        ExcluirServico excluirServico = new ExcluirServico();
        excluirServico.setVisible(true);
    }//GEN-LAST:event_ExcluirServicoActionPerformed
    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        AlterServico alterServico = new AlterServico();
        alterServico.setVisible(true);
    }//GEN-LAST:event_jMenuItem2ActionPerformed
    private void jMenuItem5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem5ActionPerformed
        new Relatorios2().setVisible(true);
    }//GEN-LAST:event_jMenuItem5ActionPerformed

    private void jToggleButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton1ActionPerformed
        Logar logar = new Logar();
        logar.setVisible(true);
        dispose();
    }//GEN-LAST:event_jToggleButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
    dispose();
    }//GEN-LAST:event_jButton2ActionPerformed
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PrincipalAdm().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem ConsultarServico;
    private javax.swing.JMenuItem ExcluirServico;
    private javax.swing.JMenuItem PromoServico;
    private javax.swing.JMenuItem cadservico;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JMenuItem jMenuItem7;
    private javax.swing.JMenuItem jMenuItem9;
    private javax.swing.JToggleButton jToggleButton1;
    private javax.swing.JMenu relatorio;
    // End of variables declaration//GEN-END:variables
}
