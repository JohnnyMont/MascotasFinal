package Visual.Servico;
import Controle.Conexao;
import Controle.ControlAdministrador;
import Controle.ControlSecretaria;
import Modelo.Servicos;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
public class AlterServico extends javax.swing.JFrame {
        String preco, desconto;
        String[] array = new String[2];
        String[] array2 = new String[2];
        String[] descontoS = new String[2];
private void atualizaTabela(){
        ControlAdministrador controle = new ControlAdministrador();
        ArrayList<Servicos> lista = controle.consultarServicos();
        DefaultTableModel tbm = (DefaultTableModel) tbServicos.getModel();
        while(tbm.getRowCount() > 0){
            tbm.removeRow(0);
        }
        try{
            if(lista != null){
                int i = 0;
                for(Servicos liv : lista){
                    tbm.addRow(new String[i]);
                    tbServicos.setValueAt(liv.getId(), i, 0);
                    tbServicos.setValueAt(liv.getNome(), i, 1);
                    tbServicos.setValueAt(liv.getIndicacao(), i, 2);
                    tbServicos.setValueAt(liv.getPreco(), i, 3);
                    tbServicos.setValueAt(liv.getDisponibilidade(), i,4);
                    tbServicos.setValueAt(liv.getDesconto(), i, 5);
                    i++;
                }
            }
        }catch(Error e){
            System.out.println(e.getMessage());
        }
    }
    public AlterServico() {
        initComponents();
        atualizaTabela();
        ControlSecretaria controle = new ControlSecretaria();
        String esp = controle.visualizarEspecies();
        String[] especies = esp.split(",");
        indicacao.removeAllItems();
        for (int i=1;i<especies.length;i++) {
            indicacao.addItem(especies[i]);
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cadastrar = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        disponibilidade = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbServicos = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        indicacao = new javax.swing.JComboBox<>();
        Id = new javax.swing.JSpinner();
        jLabel13 = new javax.swing.JLabel();
        nome = new javax.swing.JTextField();
        precoR = new javax.swing.JTextField();
        precoC = new javax.swing.JTextField();
        descontoR = new javax.swing.JTextField();
        descontoC = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        cadastrar.setBackground(new java.awt.Color(0, 0, 240));
        cadastrar.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        cadastrar.setForeground(new java.awt.Color(255, 255, 255));
        cadastrar.setText("Alterar");
        cadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cadastrarActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Serif", 0, 36)); // NOI18N
        jLabel3.setText("Desconto:");

        jLabel4.setFont(new java.awt.Font("Serif", 0, 36)); // NOI18N
        jLabel4.setText("Preço:");

        jLabel10.setFont(new java.awt.Font("Serif", 0, 36)); // NOI18N
        jLabel10.setText("Disponibilidade:");

        disponibilidade.setFont(new java.awt.Font("Serif", 0, 36)); // NOI18N

        jLabel7.setFont(new java.awt.Font("Montserrat Alternates", 3, 36)); // NOI18N
        jLabel7.setText("Alterar serviços");

        jLabel1.setFont(new java.awt.Font("Serif", 0, 36)); // NOI18N
        jLabel1.setText("Indicação:");

        tbServicos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nome", "Indicação", "Preço", "Disponibilidade", "Desconto"
            }
        ));
        tbServicos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbServicosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbServicos);

        jLabel5.setFont(new java.awt.Font("Serif", 0, 36)); // NOI18N
        jLabel5.setText("ID:");

        jLabel11.setFont(new java.awt.Font("Serif", 0, 36)); // NOI18N
        jLabel11.setText(",");

        jLabel12.setFont(new java.awt.Font("Serif", 0, 36)); // NOI18N
        jLabel12.setText("R$");

        indicacao.setFont(new java.awt.Font("Serif", 0, 36)); // NOI18N
        indicacao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                indicacaoActionPerformed(evt);
            }
        });

        Id.setFont(new java.awt.Font("Serif", 0, 36)); // NOI18N

        jLabel13.setFont(new java.awt.Font("Serif", 0, 36)); // NOI18N
        jLabel13.setText("Nome:");

        nome.setFont(new java.awt.Font("Serif", 0, 36)); // NOI18N
        nome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nomeActionPerformed(evt);
            }
        });

        precoR.setFont(new java.awt.Font("Serif", 0, 36)); // NOI18N
        precoR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                precoRActionPerformed(evt);
            }
        });

        precoC.setFont(new java.awt.Font("Serif", 0, 36)); // NOI18N
        precoC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                precoCActionPerformed(evt);
            }
        });

        descontoR.setFont(new java.awt.Font("Serif", 0, 36)); // NOI18N
        descontoR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                descontoRActionPerformed(evt);
            }
        });

        descontoC.setFont(new java.awt.Font("Serif", 0, 36)); // NOI18N
        descontoC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                descontoCActionPerformed(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("Serif", 0, 36)); // NOI18N
        jLabel14.setText(",");

        jLabel15.setFont(new java.awt.Font("Serif", 0, 36)); // NOI18N
        jLabel15.setText("R$");

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cats2.png"))); // NOI18N

        jButton2.setBackground(java.awt.Color.blue);
        jButton2.setFont(new java.awt.Font("Noto Sans", 0, 48)); // NOI18N
        jButton2.setForeground(java.awt.Color.white);
        jButton2.setText("X");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(cadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, 646, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(222, 222, 222))
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel2)
                .addGap(58, 58, 58)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 795, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addGap(49, 49, 49)
                                .addComponent(jLabel15)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(descontoR, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(2, 2, 2)
                                .addComponent(jLabel14)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(descontoC, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(jLabel5)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(Id, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel13))
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel10))
                                .addGap(37, 37, 37)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(indicacao, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 423, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 365, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(61, 61, 61))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel12)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addComponent(precoR, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(18, 18, 18)
                                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(precoC, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addComponent(disponibilidade))
                                    .addComponent(nome, javax.swing.GroupLayout.PREFERRED_SIZE, 423, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(39, 39, 39)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton2))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel5)
                                    .addComponent(Id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel13)
                                    .addComponent(nome, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jButton2))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(indicacao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel1)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(3, 3, 3)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel11)
                                    .addComponent(jLabel12)
                                    .addComponent(precoR, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(precoC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(2, 2, 2))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel4)
                                .addGap(18, 18, 18)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(disponibilidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel14)
                            .addComponent(jLabel15)
                            .addComponent(descontoR, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(descontoC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(2, 2, 2)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cadastrar)
                .addGap(0, 44, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    private void cadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cadastrarActionPerformed
        try{
            Servicos servico = new Servicos();
            servico.setIndicacao(indicacao.getSelectedItem().toString());
            servico.setDesconto(descontoR.getText()+","+descontoC.getText());
            servico.setPreco(precoR.getText()+","+precoC.getText());
            servico.setNome(nome.getText());
            servico.setDisponibilidade(disponibilidade.getText());
            ControlAdministrador controle = new ControlAdministrador();
            if(controle.AlterarDadosServicos(Integer.parseInt(Id.getValue().toString()),servico)){
                JOptionPane.showMessageDialog(null,"Edição efetuada com Sucesso");
            }
        }catch(Error e){
            System.out.println(e.getMessage());
        }
        dispose();
    }//GEN-LAST:event_cadastrarActionPerformed

    private void indicacaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_indicacaoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_indicacaoActionPerformed
    private void tbServicosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbServicosMouseClicked
        Id.setValue(tbServicos.getValueAt(tbServicos.getSelectedRow(),0));
        nome.setText(tbServicos.getValueAt(tbServicos.getSelectedRow(),1).toString());
        indicacao.setSelectedItem(tbServicos.getValueAt(tbServicos.getSelectedRow(),2));
        String preco2 = tbServicos.getValueAt(tbServicos.getSelectedRow(),3).toString();
        array = preco2.split(",");
        precoR.setText(array[0]);
        precoC.setText(array[1]);
        disponibilidade.setText(tbServicos.getValueAt(tbServicos.getSelectedRow(),4).toString());
        String desconto2 = tbServicos.getValueAt(tbServicos.getSelectedRow(),5).toString();
        array2 = desconto2.split(",");
        descontoR.setText(array2[0]);
        descontoC.setText(array2[1]);
    }//GEN-LAST:event_tbServicosMouseClicked

    private void precoRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_precoRActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_precoRActionPerformed

    private void precoCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_precoCActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_precoCActionPerformed

    private void descontoRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_descontoRActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_descontoRActionPerformed

    private void descontoCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_descontoCActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_descontoCActionPerformed

    private void nomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nomeActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        dispose();
    }//GEN-LAST:event_jButton2ActionPerformed
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> {
            new AlterServico().setVisible(true);
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JSpinner Id;
    private javax.swing.JButton cadastrar;
    private javax.swing.JTextField descontoC;
    private javax.swing.JTextField descontoR;
    private javax.swing.JTextField disponibilidade;
    private javax.swing.JComboBox<String> indicacao;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField nome;
    private javax.swing.JTextField precoC;
    private javax.swing.JTextField precoR;
    private javax.swing.JTable tbServicos;
    // End of variables declaration//GEN-END:variables
}
