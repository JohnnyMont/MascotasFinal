package Visual.Servico;
import Controle.ControlAdministrador;
import Modelo.Servicos;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
public class ConsulServico extends javax.swing.JFrame {
  private void atualizaTabela(){
    ControlAdministrador controle = new ControlAdministrador();
    ArrayList<Servicos> lista = controle.consultarServicos();
    DefaultTableModel tbm = (DefaultTableModel) tbServicos.getModel();
    while(tbm.getRowCount() > 0){
        tbm.removeRow(0);
    }
    try{
        if(lista != null){
        int i = 0;
        for(Servicos liv : lista){
            tbm.addRow(new String[i]);
            tbServicos.setValueAt(liv.getId(), i, 0);
            tbServicos.setValueAt(liv.getNome(), i, 1);
            tbServicos.setValueAt(liv.getIndicacao(), i, 2);
            tbServicos.setValueAt(liv.getPreco(), i, 3);
            tbServicos.setValueAt(liv.getDisponibilidade(), i, 4);
            tbServicos.setValueAt(liv.getDesconto(), i, 5);
            i++;
            }
        }
    }catch(Error e){
        System.out.println(e.getMessage());
    }
  }
    private void atualizaTabelaId(){
        ControlAdministrador controle = new ControlAdministrador();
        ArrayList<Servicos> lista = controle.consultarServicosId(Integer.parseInt(id.getText()));
        DefaultTableModel tbm = (DefaultTableModel) tbServicos.getModel();
        while(tbm.getRowCount() > 0){
            tbm.removeRow(0);
        }
        try{
            if(lista != null){
                int i = 0;
                for(Servicos liv : lista){
                    tbm.addRow(new String[i]);
                    tbServicos.setValueAt(liv.getId(), i, 0);
                    tbServicos.setValueAt(liv.getNome(), i, 1);
                    tbServicos.setValueAt(liv.getIndicacao(), i, 2);
                    tbServicos.setValueAt(liv.getPreco(), i, 3);
                    tbServicos.setValueAt(liv.getDisponibilidade(), i, 4);
                    tbServicos.setValueAt(liv.getDesconto(), i, 5);
                    i++;
                }
            }
        }catch(Error e){
            System.out.println(e.getMessage());
        }
    }
    private void atualizaTabelaIndicacao(){
        ControlAdministrador controle = new ControlAdministrador();
        ArrayList<Servicos> lista = controle.consultarServicosIndicacao(indicacao.getSelectedItem().toString());
        DefaultTableModel tbm = (DefaultTableModel) tbServicos.getModel();
        while(tbm.getRowCount() > 0){
            tbm.removeRow(0);
        }
        try{
            if(lista != null){
                int i = 0;
                for(Servicos liv : lista){
                    tbm.addRow(new String[i]);
                    tbServicos.setValueAt(liv.getId(), i, 0);
                    tbServicos.setValueAt(liv.getNome(), i, 1);
                    tbServicos.setValueAt(liv.getIndicacao(), i, 2);
                    tbServicos.setValueAt(liv.getPreco(), i, 3);
                    tbServicos.setValueAt(liv.getDisponibilidade(), i, 4);
                    tbServicos.setValueAt(liv.getDesconto(), i, 5);
                    i++;
                }
            }
        }catch(Error e){
            System.out.println(e.getMessage());
        }
    }
    public ConsulServico() {
        setUndecorated(true);
        initComponents();
        atualizaTabela();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        id = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        cadastrar = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbServicos = new javax.swing.JTable();
        cadastrar1 = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        indicacao = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        id.setFont(new java.awt.Font("Serif", 0, 36)); // NOI18N
        id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Serif", 0, 36)); // NOI18N
        jLabel1.setText("ID:");

        cadastrar.setBackground(java.awt.Color.blue);
        cadastrar.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        cadastrar.setForeground(new java.awt.Color(255, 255, 255));
        cadastrar.setText("Consultar");
        cadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cadastrarActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Montserrat Alternates", 3, 36)); // NOI18N
        jLabel7.setText("Consultar serviços");

        jLabel3.setFont(new java.awt.Font("Serif", 0, 36)); // NOI18N
        jLabel3.setText("Indicação:");

        tbServicos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nome", "Indicação", "Preço", "Disponibilidade", "Desconto"
            }
        ));
        jScrollPane1.setViewportView(tbServicos);

        cadastrar1.setBackground(new java.awt.Color(0, 0, 240));
        cadastrar1.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        cadastrar1.setForeground(new java.awt.Color(255, 255, 255));
        cadastrar1.setText("Consultar");
        cadastrar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cadastrar1ActionPerformed(evt);
            }
        });

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cats2.png"))); // NOI18N

        jButton2.setBackground(java.awt.Color.blue);
        jButton2.setFont(new java.awt.Font("Noto Sans", 0, 48)); // NOI18N
        jButton2.setForeground(java.awt.Color.white);
        jButton2.setText("X");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        indicacao.setFont(new java.awt.Font("Serif", 0, 36)); // NOI18N
        indicacao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                indicacaoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel2)
                .addGap(34, 34, 34)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 858, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, 1004, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(99, 99, 99)
                                .addComponent(jLabel1))
                            .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(id)
                            .addComponent(indicacao, 0, 485, Short.MAX_VALUE))
                        .addGap(51, 51, 51)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(cadastrar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cadastrar1, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(294, 294, 294)
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 321, Short.MAX_VALUE)
                        .addComponent(jButton2))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(13, 13, 13)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2))
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(cadastrar)
                        .addGap(14, 14, 14)
                        .addComponent(cadastrar1))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addGap(14, 14, 14)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(indicacao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 23, Short.MAX_VALUE)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(179, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(54, 54, 54)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_idActionPerformed
    private void cadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cadastrarActionPerformed
        atualizaTabelaId();
    }//GEN-LAST:event_cadastrarActionPerformed
    private void cadastrar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cadastrar1ActionPerformed
        atualizaTabelaIndicacao();
    }//GEN-LAST:event_cadastrar1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void indicacaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_indicacaoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_indicacaoActionPerformed
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ConsulServico().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cadastrar;
    private javax.swing.JButton cadastrar1;
    private javax.swing.JTextField id;
    private javax.swing.JComboBox<String> indicacao;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbServicos;
    // End of variables declaration//GEN-END:variables
}
