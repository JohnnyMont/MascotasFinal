package Visual.Animal;
import Controle.ControlSecretaria;
import Modelo.Animais;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
public class ExcluirAnimal extends javax.swing.JFrame {
    private void atualizaTabela(){
        ControlSecretaria controle = new ControlSecretaria();
        ArrayList<Animais> lista = controle.visualizarAnimais();
        DefaultTableModel tbm = (DefaultTableModel) tbAnimais.getModel();
        while(tbm.getRowCount() > 0){
            tbm.removeRow(0);
        }
        try{
            if(lista != null){
                int i = 0;
                for(Animais liv : lista){
                    tbm.addRow(new String[i]);
                    tbAnimais.setValueAt(liv.getId(), i, 0);
                    tbAnimais.setValueAt(liv.getNome(), i, 1);
                    tbAnimais.setValueAt(liv.getTipo(), i, 2);
                    tbAnimais.setValueAt(liv.getTamanho(), i, 3);
                    tbAnimais.setValueAt(liv.getRaca(), i, 4);
                    tbAnimais.setValueAt(liv.getPeso(), i, 5);
                    tbAnimais.setValueAt(liv.getIdade(), i, 6);
                    tbAnimais.setValueAt(liv.getCpf_cliente(), i, 7);
                    i++;
                }
            }
        }catch(Error e){
            System.out.println(e.getMessage());
        }
    }
    public ExcluirAnimal() {
        setUndecorated(true);
        initComponents();
        atualizaTabela();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel9 = new javax.swing.JLabel();
        excluir = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbAnimais = new javax.swing.JTable();
        jToggleButton2 = new javax.swing.JToggleButton();
        id = new javax.swing.JSpinner();
        jLabel13 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        excluir.setBackground(new java.awt.Color(0, 0, 240));
        excluir.setFont(new java.awt.Font("Serif", 1, 36)); // NOI18N
        excluir.setForeground(new java.awt.Color(255, 255, 255));
        excluir.setText("Excluir");
        excluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                excluirActionPerformed(evt);
            }
        });
        excluir.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                excluirKeyPressed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Serif", 0, 36)); // NOI18N
        jLabel3.setText("ID:");

        jLabel7.setFont(new java.awt.Font("Montserrat Alternates", 3, 36)); // NOI18N
        jLabel7.setText("Indetifique o Animal que será excluido");

        tbAnimais.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Id", "Nome", "Tipo", "Tamanho", "Raça", "Peso", "Idade", "CPF do Cliente"
            }
        ));
        tbAnimais.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbAnimaisMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tbAnimais);
        if (tbAnimais.getColumnModel().getColumnCount() > 0) {
            tbAnimais.getColumnModel().getColumn(1).setResizable(false);
            tbAnimais.getColumnModel().getColumn(5).setResizable(false);
        }

        jToggleButton2.setBackground(java.awt.Color.blue);
        jToggleButton2.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jToggleButton2.setForeground(new java.awt.Color(255, 255, 255));
        jToggleButton2.setText("Voltar");
        jToggleButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton2ActionPerformed(evt);
            }
        });

        id.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        id.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                idKeyPressed(evt);
            }
        });

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cats2.png"))); // NOI18N

        jButton2.setBackground(java.awt.Color.blue);
        jButton2.setFont(new java.awt.Font("Noto Sans", 0, 48)); // NOI18N
        jButton2.setForeground(java.awt.Color.white);
        jButton2.setText("X");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jToggleButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(150, 150, 150)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(excluir, javax.swing.GroupLayout.PREFERRED_SIZE, 659, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton2))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 659, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(81, 81, 81)
                                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel3)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(id, javax.swing.GroupLayout.PREFERRED_SIZE, 609, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(181, 181, 181))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(11, 11, 11)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel7)
                    .addComponent(jButton2))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jToggleButton2))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(40, 40, 40)
                        .addComponent(excluir)
                        .addGap(60, 60, 60)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(220, Short.MAX_VALUE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    private void excluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_excluirActionPerformed
        ControlSecretaria controle = new ControlSecretaria();
        if(controle.excluirAnimais(Integer.parseInt(id.getValue().toString()))){
            JOptionPane.showMessageDialog(null,"Exclusão efetuada com Sucesso");
            dispose();
        }else{
            JOptionPane.showMessageDialog(null,"Coloque um ID Válido!");   
            id.requestFocus();
        }
    }//GEN-LAST:event_excluirActionPerformed
    private void jToggleButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton2ActionPerformed
        dispose();
    }//GEN-LAST:event_jToggleButton2ActionPerformed

    private void tbAnimaisMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbAnimaisMouseClicked
        id.setValue(tbAnimais.getValueAt(tbAnimais.getSelectedRow(),0));
        excluir.requestFocus();
    }//GEN-LAST:event_tbAnimaisMouseClicked

    private void excluirKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_excluirKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER){
            ControlSecretaria controle = new ControlSecretaria();
            if(controle.excluirAnimais(Integer.parseInt(id.getValue().toString()))){
                JOptionPane.showMessageDialog(null,"Exclusão efetuada com Sucesso");
                dispose();
            }else{
                JOptionPane.showMessageDialog(null,"Coloque um ID Válido!");   
                id.requestFocus();
            }
        }
    }//GEN-LAST:event_excluirKeyPressed

    private void idKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_idKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER){
            excluir.requestFocus();
        }
    }//GEN-LAST:event_idKeyPressed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        dispose();
    }//GEN-LAST:event_jButton2ActionPerformed
   public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> {
            new ExcluirAnimal().setVisible(true);
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton excluir;
    private javax.swing.JSpinner id;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JToggleButton jToggleButton2;
    private javax.swing.JTable tbAnimais;
    // End of variables declaration//GEN-END:variables
}
