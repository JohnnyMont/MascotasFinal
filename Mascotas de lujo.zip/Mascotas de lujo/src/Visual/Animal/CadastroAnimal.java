package Visual.Animal;
import Controle.ControlSecretaria;
import Modelo.Animais;
import Visual.PrincipalSecretaria;
import javax.swing.ButtonGroup;
import javax.swing.JOptionPane;
public class CadastroAnimal extends javax.swing.JFrame {
    public CadastroAnimal() {
        initComponents();
        ControlSecretaria controle = new ControlSecretaria();
        String esp = controle.visualizarEspecies();
        String[] especies = esp.split(",");
        especie.removeAllItems();
        for (int i=1;i<especies.length;i++) {
            especie.addItem(especies[i]);
        }
        ButtonGroup buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup1.add(pequeno);
        buttonGroup1.add(medio);
        buttonGroup1.add(grande);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel7 = new javax.swing.JLabel();
        raca = new javax.swing.JComboBox<>();
        kilos = new javax.swing.JSpinner();
        jLabel9 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        gramas = new javax.swing.JSpinner();
        jLabel12 = new javax.swing.JLabel();
        idade = new javax.swing.JSpinner();
        jLabel6 = new javax.swing.JLabel();
        cpf_cliente = new javax.swing.JTextField();
        try{
            javax.swing.text.MaskFormatter cpf2= new javax.swing.text.MaskFormatter("###.###.###-##");
            cpf_cliente = new javax.swing.JFormattedTextField(cpf2);
        }
        catch (Exception e){
            JOptionPane.showMessageDialog(null,"Digite o campo CPF correto!!", "Programinha",JOptionPane.ERROR_MESSAGE);
        }
        nome = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        cadastrar = new javax.swing.JButton();
        grande = new javax.swing.JRadioButton();
        jLabel13 = new javax.swing.JLabel();
        medio = new javax.swing.JRadioButton();
        jLabel3 = new javax.swing.JLabel();
        pequeno = new javax.swing.JRadioButton();
        especie = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jToggleButton2 = new javax.swing.JToggleButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel7.setFont(new java.awt.Font("Montserrat Alternates", 3, 48)); // NOI18N
        jLabel7.setText("Cadastrar Animal");

        raca.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        raca.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                racaMouseClicked(evt);
            }
        });

        kilos.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jLabel9.setText("Kg");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jLabel5.setText("Peso:");

        gramas.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N

        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jLabel12.setText("g");

        idade.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jLabel6.setText("Idade:");

        cpf_cliente.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        cpf_cliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cpf_clienteActionPerformed(evt);
            }
        });

        nome.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        nome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nomeActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jLabel10.setText("Espécie:");

        cadastrar.setBackground(java.awt.Color.blue);
        cadastrar.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        cadastrar.setForeground(new java.awt.Color(255, 255, 255));
        cadastrar.setText("Cadastrar");
        cadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cadastrarActionPerformed(evt);
            }
        });

        grande.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        grande.setText("Grande");

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jLabel13.setText("Tamanho:");

        medio.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        medio.setText("Médio");
        medio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                medioActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jLabel3.setText("Nome:");

        pequeno.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        pequeno.setText("Pequeno");
        pequeno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pequenoActionPerformed(evt);
            }
        });

        especie.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        especie.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                especieItemStateChanged(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jLabel4.setText("Raça:");

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cats.png"))); // NOI18N

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jLabel1.setText("CPF do Cliente:");

        jToggleButton2.setBackground(java.awt.Color.blue);
        jToggleButton2.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jToggleButton2.setForeground(new java.awt.Color(255, 255, 255));
        jToggleButton2.setText("Voltar");
        jToggleButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(842, 842, 842)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 547, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addGap(24, 24, 24)
                            .addComponent(jLabel11))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(0, 0, Short.MAX_VALUE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jLabel6)
                                        .addComponent(jLabel5)
                                        .addComponent(jLabel1))
                                    .addGap(18, 18, 18)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(cpf_cliente, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(kilos, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(12, 12, 12)
                                            .addComponent(jLabel9)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(gramas, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(jLabel12))
                                        .addComponent(idade, javax.swing.GroupLayout.PREFERRED_SIZE, 521, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel13)
                                            .addGap(15, 15, 15))
                                        .addGroup(layout.createSequentialGroup()
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addComponent(jLabel10)
                                                .addComponent(jLabel4)
                                                .addComponent(jLabel3))
                                            .addGap(18, 18, 18)))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(raca, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(nome)
                                        .addComponent(especie, javax.swing.GroupLayout.PREFERRED_SIZE, 524, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                            .addGap(10, 10, 10)
                                            .addComponent(pequeno)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(medio)
                                            .addGap(43, 43, 43)
                                            .addComponent(grande))))
                                .addComponent(cadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, 825, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(221, 221, 221)
                            .addComponent(jToggleButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(34, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(jLabel11)
                .addGap(0, 0, 0)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nome, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(especie))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(pequeno)
                            .addComponent(medio)
                            .addComponent(grande)))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(raca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(gramas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel12)
                        .addComponent(jLabel9)
                        .addComponent(kilos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(7, 7, 7)
                        .addComponent(idade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(jLabel6)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cpf_cliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(cadastrar)
                        .addGap(63, 63, 63))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jToggleButton2)
                        .addGap(34, 34, 34))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cpf_clienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cpf_clienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cpf_clienteActionPerformed

    private void nomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nomeActionPerformed

    private void cadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cadastrarActionPerformed
        PrincipalSecretaria visualizar = new PrincipalSecretaria();
        Animais animal = new Animais();
        animal.setNome(nome.getText());
        animal.setTipo(especie.getSelectedItem().toString());
        if(grande.isSelected()){
            animal.setTamanho("Grande");
        }else if(medio.isSelected()){
            animal.setTamanho("Medio");
        }else if(pequeno.isSelected()){
            animal.setTamanho("Pequeno");
        }
        animal.setRaca(raca.getSelectedItem().toString());
        animal.setPeso(kilos.getValue().toString()+","+gramas.getValue().toString());
        animal.setIdade(Integer.parseInt(idade.getValue().toString()));
        animal.setCpf_cliente(cpf_cliente.getText());
        ControlSecretaria controle = new ControlSecretaria();
        if(controle.cadastrarAnimais(animal)){
            JOptionPane.showMessageDialog(null,"Cadastro efetuado com Sucesso");
            dispose();
        }
    }//GEN-LAST:event_cadastrarActionPerformed

    private void medioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_medioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_medioActionPerformed

    private void pequenoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pequenoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pequenoActionPerformed

    private void jToggleButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton2ActionPerformed
        dispose();
    }//GEN-LAST:event_jToggleButton2ActionPerformed

    private void racaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_racaMouseClicked
        
    }//GEN-LAST:event_racaMouseClicked

    private void especieItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_especieItemStateChanged
        int itemAnimal = raca.getItemCount();
        for(int i=0;i<itemAnimal;i++){
            raca.removeItemAt(0);
        }
        ControlSecretaria controle = new ControlSecretaria();
        String racas = controle.visualizarRaca(especie.getSelectedItem().toString());
        String[] rac = racas.split(",");
        for (int i = 1;i<rac.length;i++) {
            raca.addItem(rac[i]);
        }
    }//GEN-LAST:event_especieItemStateChanged
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CadastroAnimal().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cadastrar;
    private javax.swing.JTextField cpf_cliente;
    private javax.swing.JComboBox<String> especie;
    private javax.swing.JSpinner gramas;
    private javax.swing.JRadioButton grande;
    private javax.swing.JSpinner idade;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JToggleButton jToggleButton2;
    private javax.swing.JSpinner kilos;
    private javax.swing.JRadioButton medio;
    private javax.swing.JTextField nome;
    private javax.swing.JRadioButton pequeno;
    private javax.swing.JComboBox<String> raca;
    // End of variables declaration//GEN-END:variables
}
