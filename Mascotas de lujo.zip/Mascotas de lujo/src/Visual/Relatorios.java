package Visual;
import Controle.ControlAdministrador;
import Controle.ControlSecretaria;
import Modelo.Animais;
import Modelo.Cliente;
import Modelo.Compra;
import Modelo.Servicos;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
public class Relatorios extends javax.swing.JFrame {
  private void atualizaTabela(){
      ControlSecretaria controle = new ControlSecretaria();
        	ArrayList<Cliente> lista = controle.visualizarClientes();
        	DefaultTableModel tbm = (DefaultTableModel) tbClientes.getModel();
        	while(tbm.getRowCount() > 0){
            		tbm.removeRow(0);
        	}
                try{
                if(lista != null){
                    int i = 0;
                    for(Cliente liv : lista){
        		tbm.addRow(new String[i]);
        		tbClientes.setValueAt(liv.getNome(), i, 0);
                        tbClientes.setValueAt(liv.getCpf(), i, 1);
                        tbClientes.setValueAt(liv.getEmail(), i, 2);
                        tbClientes.setValueAt(liv.getTelefone(), i, 3);
                        tbClientes.setValueAt(liv.getEndereco(), i, 4);
                        i++;
                    }
                }
                 }catch(Error e){
            System.out.println(e.getMessage());
        }
        ArrayList<Compra> lista4 = controle.consultarCompras();
        	DefaultTableModel tbm4 = (DefaultTableModel) tbCompras.getModel();
        	while(tbm4.getRowCount() > 0){
            		tbm4.removeRow(0);
        	}
                try{
                if(lista4 != null){
                    int i = 0;
                    for(Compra liv : lista4){
        		tbm4.addRow(new String[i]);
                        tbCompras.setValueAt(liv.getCpfCliente(), i, 0);
                        tbCompras.setValueAt(liv.getCodAnimal(), i, 1);
                        tbCompras.setValueAt(liv.getTotal(), i, 2);
                        tbCompras.setValueAt(liv.getFormaPagamento(), i, 3);
                        i++;
                    }
                }
                 }catch(Error e){
            System.out.println(e.getMessage());
        }
        ArrayList<Animais> lista3 = controle.visualizarAnimais();
        DefaultTableModel tbm3 = (DefaultTableModel) tbAnimais.getModel();
        while(tbm3.getRowCount() > 0){
            tbm3.removeRow(0);
        }
        try{
            if(lista3 != null){
            int i = 0;
                for(Animais liv3 : lista3){
                    tbm3.addRow(new String[i]);
                    tbAnimais.setValueAt(liv3.getNome(), i, 0);
                    tbAnimais.setValueAt(liv3.getTipo(), i, 1);
                    tbAnimais.setValueAt(liv3.getRaca(), i, 2);
                    tbAnimais.setValueAt(liv3.getTamanho(), i, 3);
                    tbAnimais.setValueAt(liv3.getIdade(), i, 4);
                    tbAnimais.setValueAt(liv3.getCpf_cliente(), i, 5);
                    i++;
                }
            }
        }catch(Error e){
            System.out.println(e.getMessage());
        }
    ControlAdministrador controle2 = new ControlAdministrador();
    ArrayList<Servicos> lista2 = controle2.consultarServicos();
    DefaultTableModel tbm2 = (DefaultTableModel) tbServicos.getModel();
    while(tbm2.getRowCount() > 0){
        tbm2.removeRow(0);
    }
    try{
        if(lista2 != null){
        int i = 0;
        for(Servicos liv2 : lista2){
            tbm2.addRow(new String[i]);
            tbServicos.setValueAt(liv2.getNome(), i, 0);
            tbServicos.setValueAt(liv2.getIndicacao(), i, 1);
            tbServicos.setValueAt(liv2.getPreco(), i, 2);
            tbServicos.setValueAt(liv2.getDisponibilidade(), i, 3);
            tbServicos.setValueAt(liv2.getDesconto(), i, 4);
            i++;
            }
        }
    }catch(Error e){
        System.out.println(e.getMessage());
    }
  }
    public Relatorios() {
        initComponents();
        atualizaTabela();
        voltar.requestFocus();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbServicos = new javax.swing.JTable();
        voltar = new javax.swing.JToggleButton();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbCompras = new javax.swing.JTable();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbClientes = new javax.swing.JTable();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tbAnimais = new javax.swing.JTable();
        jLabel11 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel7.setFont(new java.awt.Font("Montserrat Alternates", 3, 48)); // NOI18N
        jLabel7.setText("Serviços");

        tbServicos.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        tbServicos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Nome", "Indicação", "Preço", "Disponibilidade", "Desconto"
            }
        ));
        jScrollPane1.setViewportView(tbServicos);

        voltar.setBackground(new java.awt.Color(0, 0, 240));
        voltar.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        voltar.setForeground(new java.awt.Color(255, 255, 255));
        voltar.setText("Voltar");
        voltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                voltarActionPerformed(evt);
            }
        });
        voltar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                voltarKeyPressed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Montserrat Alternates", 3, 48)); // NOI18N
        jLabel8.setText("Compras");

        tbCompras.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        tbCompras.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "CPF do Cliente", "Codigo do Animal", "Total", "Forma de Pagamento"
            }
        ));
        jScrollPane2.setViewportView(tbCompras);

        jLabel9.setFont(new java.awt.Font("Montserrat Alternates", 3, 48)); // NOI18N
        jLabel9.setText("Clientes");

        tbClientes.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        tbClientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Nome", "CPF", "Email", "Telefone", "Endereço"
            }
        ));
        jScrollPane3.setViewportView(tbClientes);

        jLabel10.setFont(new java.awt.Font("Montserrat Alternates", 3, 48)); // NOI18N
        jLabel10.setText("Animais");

        tbAnimais.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        tbAnimais.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Nome", "Tipo", "Raça", "Tamanho", "Idade", "CPF do Cliente"
            }
        ));
        jScrollPane4.setViewportView(tbAnimais);

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cats.png"))); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 276, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(691, 691, 691))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(736, 736, 736))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addGap(739, 739, 739))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(voltar, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane4)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel8)
                                        .addGap(736, 736, 736))
                                    .addGroup(layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jScrollPane2))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(5, 5, 5)
                                        .addComponent(jScrollPane1))))
                            .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 1881, Short.MAX_VALUE))))
                .addGap(29, 29, 29))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(voltar)
                .addGap(34, 34, 34))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void voltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_voltarActionPerformed
        PrincipalAdm visualizar = new PrincipalAdm();
        visualizar.setVisible(true);
        dispose();
    }//GEN-LAST:event_voltarActionPerformed

    private void voltarKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_voltarKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER){
            dispose();
        }
    }//GEN-LAST:event_voltarKeyPressed
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> {
            new Relatorios().setVisible(true);
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTable tbAnimais;
    private javax.swing.JTable tbClientes;
    private javax.swing.JTable tbCompras;
    private javax.swing.JTable tbServicos;
    private javax.swing.JToggleButton voltar;
    // End of variables declaration//GEN-END:variables
}
