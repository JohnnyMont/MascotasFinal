package Modelo;
public class Admin extends User{
    private String senhaExtra;
    public Admin(){
        super(0,"admin","admin123");
    }
    public String getSenhaExtra() {
        return senhaExtra;
    }
    public void setSenhaExtra(String senhaExtra) {
        this.senhaExtra = senhaExtra;
    }
}
