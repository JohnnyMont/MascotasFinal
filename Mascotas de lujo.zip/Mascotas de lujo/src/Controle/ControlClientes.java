package Controle;
import Modelo.Cliente;
import Modelo.Servicos;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
public class ControlClientes {
    private Cliente cliente;
    public ArrayList consultarServicosId(int id){
        ArrayList lista = new ArrayList<>();
        try{
            Conexao conectar = new Conexao();
            PreparedStatement ps = conectar.getCon().prepareStatement("SELECT * FROM servicos WHERE id = ?");
            ps.setInt(1,id);
            ResultSet rs = ps.executeQuery();
            if(rs != null){
                while(rs.next()){
                    Servicos li = new Servicos();
                    li.setId(rs.getInt("id"));
                    li.setIndicacao(rs.getString("indicacao"));
                    li.setDesconto(rs.getString("desconto"));
                    li.setDisponibilidade(rs.getString("disponibilidade"));
                    li.setPreco(rs.getString("preco"));
                    lista.add(li);
                }
            }else{
                lista = null;
            }
        }catch(SQLException e){
            lista = null;
            System.out.println(e.getMessage());
        }
        return lista;
    }
    public ArrayList consultarServicosIndicacao(String indicacao){
        ArrayList lista = new ArrayList<>();
        try{
            Conexao conectar = new Conexao();
            PreparedStatement ps = conectar.getCon().prepareStatement("SELECT * FROM servicos WHERE indicacao = ?");
            ps.setString(1,indicacao);
            ResultSet rs = ps.executeQuery();
            if(rs != null){ 
                while(rs.next()){
                    Servicos li = new Servicos();
                    li.setId(rs.getInt("id"));
                    li.setIndicacao(rs.getString("indicacao"));
                    li.setDesconto(rs.getString("desconto"));
                    li.setDisponibilidade(rs.getString("disponibilidade"));
                    li.setPreco(rs.getString("preco"));
                    lista.add(li);
                }
            }else{
                lista = null;
            }
        }catch(SQLException e){
            lista = null;
            System.out.println(e.getMessage());
        }
        return lista;
    }
    public ArrayList listarPromocoes(){
        ArrayList lista = new ArrayList<>();
        try{
            Conexao conectar = new Conexao();
            PreparedStatement ps = conectar.getCon().prepareStatement("SELECT * FROM servicos WHERE desconto != 0");
            ResultSet rs = ps.executeQuery();
            if(rs != null){ 
                while(rs.next()){ 
                    Servicos li = new Servicos();
                    li.setId(rs.getInt("id"));
                    li.setIndicacao(rs.getString("indicacao"));
                    li.setDesconto(rs.getString("desconto"));
                    li.setDisponibilidade(rs.getString("disponibilidade"));
                    li.setPreco(rs.getString("preco"));
                    lista.add(li);
                }
            }else{
                lista = null;
            }
        }catch(SQLException e){
            lista = null;
            System.out.println(e.getMessage());
        }
        return lista;
    }
}