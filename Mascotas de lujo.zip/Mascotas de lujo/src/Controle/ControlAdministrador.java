package Controle;
import Modelo.Servicos;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
public class ControlAdministrador {
    public boolean cadastrarServicos(Servicos servico){
        boolean resultado = false;
        try{
            Conexao conectar = new Conexao();
            PreparedStatement ps2 = conectar.getCon().prepareStatement("INSERT INTO servicos(disponibilidade,indicacao,preco,desconto,nome) VALUES(?,?,?,?,?);");
            ps2.setString(1,servico.getDisponibilidade());
            ps2.setString(2,servico.getIndicacao());
            ps2.setString(3,servico.getPreco());
            ps2.setString(4,servico.getDesconto());
            ps2.setString(5,servico.getNome());
            if(!ps2.execute()){ 
                resultado = true;
            }
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
        return resultado;
    }
    public boolean AlterarDadosServicos(int id, Servicos servico){
        int id_oficial = id;
        try{
            Conexao conectar = new Conexao();
            PreparedStatement ps = conectar.getCon().prepareStatement("UPDATE servicos SET disponibilidade=?, indicacao=?, preco=?, desconto=?,nome = ? WHERE id=?");
            ps.setString(1,servico.getDisponibilidade());
            ps.setString(2,servico.getIndicacao());
            ps.setString(3,servico.getPreco());
            ps.setString(4,servico.getDesconto());
            ps.setString(5,servico.getNome());
            ps.setInt(6,id_oficial);
            ps.execute();
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
        return true;
    }
    public boolean colocarPromocao(int id, String desconto){
        try{
            Conexao conectar = new Conexao();
            PreparedStatement ps = conectar.getCon().prepareStatement("UPDATE servicos SET desconto=? WHERE id=?");
            ps.setString(1,desconto);
            ps.setInt(2,id);
            ps.execute();
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
        return true;
    }
    public boolean excluirServicos(int id){
        try{
            Conexao conectar = new Conexao();
            PreparedStatement ps2 = conectar.getCon().prepareStatement("DELETE FROM servicos WHERE id=?");
            ps2.setInt(1,id);
            ps2.execute();
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
        return true;
    }
    public ArrayList consultarServicos(){
        ArrayList lista = new ArrayList<>();
        try{
            Conexao conectar = new Conexao();
            PreparedStatement ps = conectar.getCon().prepareStatement("SELECT * FROM servicos");
            ResultSet rs = ps.executeQuery();
            if(rs != null){ 
                while(rs.next()){ 
                    Servicos li = new Servicos();
                    li.setId(rs.getInt("id"));
                    li.setNome(rs.getString("nome"));
                    li.setIndicacao(rs.getString("indicacao"));
                    li.setDesconto(rs.getString("desconto"));
                    li.setDisponibilidade(rs.getString("disponibilidade"));
                    li.setPreco(rs.getString("preco"));
                    lista.add(li);
                }
            }else{
                lista = null;
            }
        }catch(SQLException e){
            lista = null;
            System.out.println(e.getMessage());
        }
        return lista;
    }
    public ArrayList consultarServicosId(int id){
        ArrayList lista = new ArrayList<>();
        try{
            Conexao conectar = new Conexao();
            PreparedStatement ps = conectar.getCon().prepareStatement("SELECT * FROM servicos WHERE id = ?");
            ps.setInt(1,id);
            ResultSet rs = ps.executeQuery();
            if(rs != null){
                while(rs.next()){
                    Servicos li = new Servicos();
                    li.setId(rs.getInt("id"));
                    li.setNome(rs.getString("nome"));
                    li.setIndicacao(rs.getString("indicacao"));
                    li.setDesconto(rs.getString("desconto"));
                    li.setDisponibilidade(rs.getString("disponibilidade"));
                    li.setPreco(rs.getString("preco"));
                    lista.add(li);
                }
            }else{
                lista = null;
            }
        }catch(SQLException e){
            lista = null;
            System.out.println(e.getMessage());
        }
        return lista;
    }
    public ArrayList consultarServicosIndicacao(String indicacao){
        ArrayList lista = new ArrayList<>();
        try{
            Conexao conectar = new Conexao();
            PreparedStatement ps = conectar.getCon().prepareStatement("SELECT * FROM servicos WHERE indicacao = ?");
            ps.setString(1,indicacao);
            ResultSet rs = ps.executeQuery();
            if(rs != null){ 
                while(rs.next()){
                    Servicos li = new Servicos();
                    li.setId(rs.getInt("id"));
                    li.setNome(rs.getString("nome"));
                    li.setIndicacao(rs.getString("indicacao"));
                    li.setDesconto(rs.getString("desconto"));
                    li.setDisponibilidade(rs.getString("disponibilidade"));
                    li.setPreco(rs.getString("preco"));
                    lista.add(li);
                }
            }else{
                lista = null;
            }
        }catch(SQLException e){
            lista = null;
            System.out.println(e.getMessage());
        }
        return lista;
    }
    public boolean confirmar(String senhaU){
        try{
            Conexao conectar = new Conexao();
            PreparedStatement ps = conectar.getCon().prepareStatement("SELECT * FROM administrador WHERE senhaExtra = ?;");
            ps.setString(1,senhaU);
            ResultSet rs = ps.executeQuery();
            if(rs != null){
                while(rs.next()){
                    return true;
                }
            }
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
        return false;
    }
}
